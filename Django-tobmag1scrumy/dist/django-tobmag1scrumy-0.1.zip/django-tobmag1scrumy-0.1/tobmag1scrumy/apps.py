from django.apps import AppConfig


class Tobmag1ScrumyConfig(AppConfig):
    name = 'tobmag1scrumy'
